app.controller('optionsController',  optionsController);

function optionsController($scope,template,getOptions,save,retrive,deleteObject){
	
	$scope.user = {name:"",city:"",email:"",contact:"",position:"left"};
	$scope.objective = {objective:""};
	$scope.academic=[];
	$scope.certification=[];
	$scope.achievement=[];
	$scope.curricular=[];
	$scope.technical=[];
	$scope.experience=[];
	$scope.interest=[];
	$scope.project=[];
	$scope.toggle={showObjective:false,showAcademic:false,showUpdate:false,showCertification:false,showAchievement:false,showTechnical:false,showExperience:false,showInterest:false,showProject:false};
	$scope.academicObject={qualification:"",institute:"",board:"",year:"",percentage:""};
	$scope.certificationObject={certification:"",year:""};
	$scope.achievementObject={achievement:""};
	$scope.curricularObject={curricular:""};
	$scope.technicalObject={technical:""};
	$scope.interestObject={interest:""};
	$scope.experienceObject={company:"",to:"",from:"",role:"",description:""};
	$scope.projectObject={title:"",client:"",technology:"",description:""};
	//Intialization Start
	initialize();
	//Intialization End
	
	//Service Call To fetch and fill All Available Options
	getOptions.options().then(function(response){
		$scope.options=response.data;
		$scope.selectedOption = $scope.options[0];
		$scope.update($scope.options[0]);
	});
    //END
	
	//Update Template
	$scope.update=function(e){
		$scope.form='view/'+template.getTemplate(e);
	};
	//END
	
	// SAVE DATA
	$scope.addData=function(key){	
		switch(key){		
		case 'academic':
			$scope.academicObject={qualification:"",institute:"",board:"",year:"",percentage:""};
			$scope.academic.push($scope.academicObject);			
			break;
		case 'certification':			
			$scope.certificationObject={certification:"",year:""};
			$scope.certification.push($scope.certificationObject);			
			break;
		case 'achievement':
			$scope.achievementObject={achievement:""};
			$scope.achievement.push($scope.achievementObject);			
			break;
		case 'curricular':
			$scope.curricularObject={curricular:""};
			$scope.curricular.push($scope.curricularObject);			
			break;
		case 'technical':
			$scope.technicalObject={technical:""};
			$scope.technical.push($scope.technicalObject);			
			break;
		case 'interest':
			$scope.interestObject={interest:""};
			$scope.interest.push($scope.interestObject);			
			break;
		case 'experience':
			$scope.experienceObject={company:"",to:"",from:"",role:"",description:""};
			$scope.experience.push($scope.experienceObject);			
			break;
		case 'project':
			$scope.projectObject={title:"",client:"",technology:"",description:""};
			$scope.project.push($scope.projectObject);			
			break;
		}
		
	};
	//END
	
	// SAVE DATA
	$scope.saveData=function(key){	
		switch(key){
		case 'intro':
			save.saveData("intro",$scope.user);
			break;
		case 'objective':
			save.saveData("objective",$scope.objective);
			break;
		case 'academic':		
			save.saveData("academic",$scope.academic);
			break;
		case 'certification':						
			save.saveData("certification",$scope.certification);
			break;
		case 'achievement':			
			save.saveData("achievement",$scope.achievement);
			break;
		case 'curricular':			
			save.saveData("curricular",$scope.curricular);
			break;
		case 'technical':			
			save.saveData("technical",$scope.technical);
			break;
		case 'experience':			
			save.saveData("experience",$scope.experience);
			break;
		case 'interest':			
			save.saveData("interest",$scope.interest);
			break;
		case 'project':			
			save.saveData("project",$scope.project);
			break;
		}
		
	};
	//END
	
	//EDIT
	$scope.editData=function(key,index){
		$scope.toggle.showUpdate=true;
		switch(key){
		case 'academic':
			$scope.academicObject=$scope.academic[index];
			$scope.toggle.showAcademic=true;
			break;
		case 'certification':
			$scope.certificationObject=$scope.certification[index];
			$scope.toggle.showCertification=true;
			break;
		case 'achievement':
			$scope.achievementObject=$scope.achievement[index];
			$scope.toggle.showAchievement=true;
			break;
		case 'curricular':
			$scope.curricularObject=$scope.curricular[index];
			$scope.toggle.showCurricular=true;
			break;
		case 'technical':
			$scope.technicalObject=$scope.technical[index];
			$scope.toggle.showTechnical=true;
			break;
		case 'experience':
			$scope.experienceObject=$scope.experience[index];
			$scope.toggle.showExperience=true;
			break;
		case 'interest':
			$scope.interestObject=$scope.interest[index];
			$scope.toggle.showInterest=true;
			break;
		case 'project':
			$scope.projectObject=$scope.project[index];
			$scope.toggle.showProject=true;
			break;
		}
	};
	//EDIT
	
	//DELETE DATA
	$scope.deleteData=function(key,index){	
		switch(key){
		case 'objective':
			$scope.objective = {};
			localStorage.removeItem(key);
			break;
		case 'academic':
			$scope.academic.splice(index,1);
			save.saveData("academic",$scope.academic);
			break;
		case 'certification':
			$scope.certification.splice(index,1);
			save.saveData("certification",$scope.certification);
			break;
		case 'achievement':
			$scope.achievement.splice(index,1);
			save.saveData("achievement",$scope.achievement);
			break;
		case 'curricular':
			$scope.curricular.splice(index,1);
			save.saveData("curricular",$scope.curricular);
			break;
		case 'technical':
			$scope.technical.splice(index,1);
			save.saveData("technical",$scope.technical);
			break;
		case 'experience':
			$scope.experience.splice(index,1);
			save.saveData("experience",$scope.experience);
			break;
		case 'interest':
			$scope.interest.splice(index,1);
			save.saveData("interest",$scope.interest);
			break;
		case 'project':
			$scope.project.splice(index,1);
			save.saveData("project",$scope.project);
			break;
		}
		
	};
	//DELETE DATA
  
	
	//CANCEL
	$scope.cancelData=function(key){
		
		switch(key){
		case 'academic':
			$scope.academic.pop();
			save.saveData("academic",$scope.academic);
			break;
		case 'certification':
			$scope.certification.pop();
			save.saveData("certification",$scope.certification);
			break;
		case 'achievement':
			$scope.achievement.pop();
			save.saveData("achievement",$scope.achievement);
			break;
		case 'curricular':
			$scope.curricular.pop();
			save.saveData("curricular",$scope.curricular);
			break;
		case 'technical':
			$scope.technical.pop();
			save.saveData("technical",$scope.technical);
			break;
		case 'experience':
			$scope.experience.pop();
			save.saveData("experience",$scope.experience);
			break;
		case 'interest':
			$scope.interest.pop();
			save.saveData("interest",$scope.interest);
			break;
		case 'project':
			$scope.project.pop();
			save.saveData("project",$scope.project);
			break;
		}
	};
	
	//CANCEL
	
	
	
	
	//INITAILIZATION FUNCTION
	function initialize(){
		if(!(retrive.getData("intro") == null)){
			$scope.user=retrive.getData("intro");
			}	
		if(!(retrive.getData("objective") == null)){
			$scope.objective=retrive.getData("objective");
			$scope.toggle.showObjective=true;
			}
		
		if(!(retrive.getData("academic") == null)){
			$scope.academic=retrive.getData("academic");
		}
	
		if(!(retrive.getData("certification") == null)){
			$scope.certification=retrive.getData("certification");
		}
	
		if(!(retrive.getData("achievement") == null)){
			$scope.achievement=retrive.getData("achievement");
		}
		if(!(retrive.getData("curricular") == null)){
			$scope.curricular=retrive.getData("curricular");
		}
		if(!(retrive.getData("technical") == null)){
			$scope.technical=retrive.getData("technical");
		}
		if(!(retrive.getData("experience") == null)){
			$scope.experience=retrive.getData("experience");
		}
		if(!(retrive.getData("interest") == null)){
			$scope.interest=retrive.getData("interest");
		}
		if(!(retrive.getData("project") == null)){
			$scope.project=retrive.getData("project");
		}
	}
//END
	
	//EXPORT TO PDF
	
	$scope.printDiv=function(divName) {
	     var printContents = document.getElementById(divName).innerHTML;
	     var originalContents = document.body.innerHTML;

	     document.body.innerHTML = printContents;

	     window.print();

	     document.body.innerHTML = originalContents;
	     location.reload();
	};
	
	

};