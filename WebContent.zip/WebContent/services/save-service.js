app.service('save',save);
function save(){
	this.saveData=function(key,data){
	localStorage.setItem(key, JSON.stringify(data));
	};
}