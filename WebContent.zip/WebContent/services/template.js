app.service('template',template);
function template(){
	this.getTemplate=function(form){
		switch(form){
		case "Introduction" :
			return "intro-form.html";
		case "Objective" :
			return "objective.html";
		case "Academic" :
			return "academic.html";
		case "Certifications" :
			return "certification.html";
		case "Technical Skills" :
			return "technical.html";
		case "Experience" :
			return "experience.html";
		case "Area of Interest" :
			return "interest-area.html";
		case "Projects" :
			return "projects.html";
		case "Achievements" :
			return "achievement.html";
		case "Extra-Curricular" :
			return "extra-curricular.html";
		}
	};
}