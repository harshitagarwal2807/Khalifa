app.service('retrive',retrive);
function retrive(){
	this.getData=function(name){
		var d=localStorage.getItem(name);
		if(!(d===undefined))
	return JSON.parse(d);
		else
			return undefined;
	};
}