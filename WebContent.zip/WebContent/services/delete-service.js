app.service('deleteObject',deleteObject);
function deleteObject(){
	this.deleteData=function(key){
	localStorage.removeItem(key);
	};
}