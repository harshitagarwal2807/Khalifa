app.service('getOptions',getOptions);

function getOptions($http){
	
	this.options=function(){
		var request={
				method:"GET",
				url:"json/options.json"
		};
		return $http(request);
	    
	};
}